﻿namespace Valikkopeli
{
    public enum GameDifficulty
    {
        Easy,
        Normal,
        Hard
    }
}
